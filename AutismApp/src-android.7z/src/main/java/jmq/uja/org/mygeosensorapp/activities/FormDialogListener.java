package jmq.uja.org.mygeosensorapp.activities;


public interface FormDialogListener {

  void update(String taskName, String taskDate);
}
