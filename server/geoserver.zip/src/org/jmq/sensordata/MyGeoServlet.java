/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.jmq.sensordata;

import com.mongodb.client.MongoClients;

import dev.morphia.Datastore;
import dev.morphia.Morphia;
import static dev.morphia.aggregation.experimental.expressions.AccumulatorExpressions.*;
import static dev.morphia.aggregation.experimental.expressions.Expressions.*;
import dev.morphia.aggregation.experimental.stages.Group;

import dev.morphia.aggregation.experimental.stages.Unset;
import dev.morphia.aggregation.experimental.stages.Unwind;

import dev.morphia.query.experimental.filters.Filters;

import static dev.morphia.aggregation.Group.*;
import static dev.morphia.aggregation.experimental.stages.Group.*;
import dev.morphia.query.experimental.filters.Filter;
import java.util.*;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.*;
import javax.ws.rs.core.*;



@Path("MyGeoServlet")
public class MyGeoServlet {
    
    
        @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String getMessage() {        
        return "Hi from rest services in geo data sensor \n";
    }

    
    static long offTimeLocation=24L*60L*60L*1000L;
    
    @GET
    @Path("/insert_location/{user}/{lat}/{lon}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response inserSensorData(
            @PathParam("user") String user,
            @PathParam("lat") Float lat,
            @PathParam("lon") Float lon
            ) {
    			
                try {
                        TimeLocation data = new TimeLocation(user, System.currentTimeMillis(), lat, lon);
                       
                        Datastore ds=getMongoDataStore(user);
                        ds.save(data);
                        System.out.println("Inserted data "+data);
                        
                         List<TimeLocation> sensors=   ds
             		.find(TimeLocation.class)
             		.filter(
             				Filters.gt("timestamp", System.currentTimeMillis()-offTimeLocation)
             		)           		
       //                 .filter(
         //    				Filters.eq("property", "p1")
         //    		)
             		.iterator()
             		.toList();
                return Response.ok()
                    .entity(sensors)
                    .build();
                } catch (Exception e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                }
                return Response.status(Response.Status.NOT_FOUND)
            .build();
    }    

 @GET
    @Path("/get_location_resources/{user}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getLocationResources(
            @PathParam("user") String user
            ) {
    			
                try {

                        Datastore ds=getMongoDataStore(user);
                        
                         List<ResourceLocation> resources=   ds
             		.find(ResourceLocation.class)
             		
             		.iterator()
             		.toList();
                return Response.ok()
                    .entity(resources)
                    .build();
                } catch (Exception e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                }
                return Response.status(Response.Status.NOT_FOUND)
            .build();
    }    
    
@GET
    @Path("/get_cash_movement/{user}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getCashMovement(
                @PathParam("user") String user
            ) {
                try {
                        Datastore ds=getMongoDataStore(user);
                        
                         List<CashMovement> resources=   ds
             		.find(CashMovement.class)
             		
             		.iterator()
             		.toList();
                return Response.ok()
                    .entity(resources)
                    .build();
                } catch (Exception e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                }
                return Response.status(Response.Status.NOT_FOUND)
            .build();
    }    
    
    
@GET
    @Path("/insert_cash_movement/{user}/{money}/{concept}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getCashMovement(
                @PathParam("user") String user,
                @PathParam("money") float money,
                @PathParam("concept") String concept
            ) {
                try {
                        Datastore ds=getMongoDataStore(user);
                        CashMovement data = new CashMovement(user,System.currentTimeMillis(), money, concept);
                        ds.save(data);
                         List<CashMovement> resources=   ds
             		.find(CashMovement.class)
             		
             		.iterator()
             		.toList();
                return Response.ok()
                    .entity(resources)
                    .build();
                } catch (Exception e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                }
                return Response.status(Response.Status.NOT_FOUND)
            .build();
    }        
        
   static  Datastore getMongoDataStore(String id) throws Exception{
         Datastore datastore = Morphia.createDatastore(MongoClients.create(),id+"-autis");
        datastore.getMapper().mapPackage("org.jmq.sensordata");
        datastore.ensureIndexes();
      
        return datastore;
    }
    
  static public void main2(String [] args) throws Exception{
        
        String user="aurora";

         Datastore datastore = getMongoDataStore(user);

     
         {
        	 ResourceLocation data = new ResourceLocation("casa", 37.15656f,-3.61188f);
        	 datastore.save(data);
         }   
         {
                ResourceLocation data = new ResourceLocation("adetem", 37.15793f,-3.60618f);
        	datastore.save(data);
         }
         {
        	 ResourceLocation data = new ResourceLocation("piso", 37.15731f,-3.61023f);
        	 datastore.save(data);
         }
  }    
  
  
   static public void main(String [] args) throws Exception{
        
        String user="aurora";

         Datastore datastore = getMongoDataStore(user);
       {
        	 CashMovement data = new CashMovement("aurora",System.currentTimeMillis(), +23.98832f, " saludo ");
        	 datastore.save(data);
         }   
     
  }    
}